let express = require('express');
let app = express();
let bodyParser = require('body-parser')
let mongoose = require('mongoose')
let mongo = require('mongodb')
const mongo_uri = process.env['MONGO_URI']

mongoose.connect(process.env['MONGO_URI'],{useNewUrlParser: true, useUnifiedTopology:true})


//middleWare
app.use("/", (req,res,next) => {
  let method = req.method;
  let path = req.path;
  let ip = req.ip;

  next()
  
})

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

let cssPath = __dirname + "/public"
app.use("/public",express.static(cssPath))

app.get("/", (req,res) => {
  let absolutePath = __dirname + "/views/index.html"
  res.sendFile(absolutePath)
})

const mySecret = process.env['MESSAGE_STYLE']



app.get("/json", (req,res) => {
  let response = "Hello json"
  if(process.env['MESSAGE_STYLE'] == "uppercase"){
   response = "Hello json".toUpperCase()
  }
   res.json({"message": response})
})

app.get("/now", (req,res,next) => {
  req.time = new Date().toString()
  next()
}, (req,res) =>{
  res.json({"time": req.time})
})

app.get("/:word/echo", (req,res) => {
  let echo = req.params.word
  res.json({"echo":echo})
})


app.get("/name", (req,res) => {
  let name = req.query.first;
  let lastname = req.query.last;
  res.json({"name": `${name} ${lastname}`})
})

app.post("/name", (req,res) => {
  let name = req.body.first;
  let lastname = req.body.last;
  res.json({"name": `${name} ${lastname}`})

})

























 module.exports = app;
